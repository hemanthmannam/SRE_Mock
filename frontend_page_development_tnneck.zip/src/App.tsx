import React from 'react'
import { Search, Filter, FileText, FileSpreadsheet, ChevronDown, User, Headset } from 'lucide-react'

function App() {
  const data = Array(10).fill({
    aysAppsImpacted: 'H9VV',
    apiAppsImpacted: 'H9VV',
    appsInAYSNotInAPI: 'H9VV',
    appsInAPINotInAYS: 'H9VV',
  })

  return (
    <div className="min-h-screen bg-gray-100 font-sans">
      {/* Header */}
      <header className="bg-black text-white py-2 px-6 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <span className="text-lg font-bold">TSGI Change Management</span>
        </div>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-1">
            <Headset size={16} />
            <span>Help / Support</span>
          </div>
          <div className="flex items-center space-x-2">
            <Search size={16} />
            <input
              type="text"
              placeholder="Search"
              className="bg-gray-800 text-white text-sm rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
          <div className="flex items-center space-x-1">
            <User size={16} />
            <span>Hello, Srujan</span>
            <ChevronDown size={16} />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        {/* Verizon Logo and Home */}
        <div className="flex items-center space-x-4 mb-6">
          {/* Using a placeholder div for the Verizon logo */}
          <div className="text-red-600 font-bold text-2xl">verizon</div>
          <div className="border-b-2 border-red-600 pb-1">
            <a href="#" className="text-gray-800 font-semibold">Home</a>
          </div>
        </div>

        {/* Change No Section */}
        <div className="mb-6">
          <h1 className="text-2xl font-semibold mb-4">Change No</h1>
          <div className="flex items-center space-x-4">
            <div className="relative flex-grow">
              <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="CHG000734158"
                className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
              <Filter size={20} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
          </div>
        </div>

        {/* Change Control and Generated At */}
        <div className="mb-6 text-sm text-gray-700">
          <p><b>Change Control:</b> CHG000734158</p>
          <p className="bg-yellow-200 inline-block px-2 py-0.5 rounded"><b>Change Generated AT:</b> Wed, Apr 23, 2025, 6:47:19 AM</p>
        </div>

        {/* Table Section */}
        <div className="bg-white shadow rounded-lg overflow-hidden mb-6">
          <div className="flex justify-end items-center p-4 space-x-2 border-b border-gray-200">
             <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-700">Sort by:</span>
                <select className="border border-gray-300 rounded-md text-sm py-1 px-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                  <option>All</option>
                </select>
             </div>
             <div className="relative">
                <Search size={16} className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search"
                  className="pl-8 pr-2 py-1 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                />
             </div>
            <Filter size={20} className="text-gray-500" />
            <FileSpreadsheet size={20} className="text-green-600" />
            <FileText size={20} className="text-green-600" />
          </div>
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  AYS Apps Impacted
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  API Apps Impacted
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Apps in AYS Not in API
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Apps in API Not in AYS
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {data.map((item, index) => (
                <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {item.aysAppsImpacted}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {item.apiAppsImpacted}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {item.appsInAYSNotInAPI}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {item.appsInAPINotInAYS}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination and Results */}
        <div className="flex justify-between items-center text-sm text-gray-700 mb-6">
          <div>
            <b>Results</b> No. of Records: <b>330</b>
          </div>
          <div className="flex items-center space-x-2">
            <span>1</span>
            <span>2</span>
            <span>3</span>
            <span>4</span>
            <a href="#" className="flex items-center space-x-1 text-blue-600 hover:underline">
              <span>Next</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </a>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-200 text-gray-700 text-xs py-4 px-6 text-center">
        <p>Proprietary and Confidential. Not for disclosure outside of Verizon. | <a href="#" className="underline">Full Legal Disclaimer</a> | <a href="#" className="underline">Browser Policy</a></p>
        <p>©2025</p>
      </footer>
    </div>
  )
}

export default App
